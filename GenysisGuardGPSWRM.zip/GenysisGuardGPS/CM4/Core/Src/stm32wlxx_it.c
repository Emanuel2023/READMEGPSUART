/* USER CODE BEGIN Header */

/**
  ******************************************************************************
  * @file    stm32wlxx_it.c
  * @brief   Interrupt Service Routines.
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2024 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */

/* USER CODE END Header */

/* Includes ------------------------------------------------------------------*/

#include "main.h"
#include "stm32wlxx_it.h"

/* Private includes ----------------------------------------------------------*/

/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/

/* USER CODE BEGIN TD */

/* USER CODE END TD */

/* Private define ------------------------------------------------------------*/

/* USER CODE BEGIN PD */

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/

/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/

/* USER CODE BEGIN PV */

uint8_t UART2_received_flag_RX = 0;
uint8_t UART2_received_data_RX = 0;

uint8_t UART1_received_flag_RX = 0;
uint8_t UART1_received_data_RX = 0;

/* USER CODE END PV */

uint8_t M10S_received_buffer_RX[36];
uint8_t M10S_RX_complete_flag = 0;

/* Private function prototypes -----------------------------------------------*/

/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/

/* USER CODE BEGIN 0 */

/* USER CODE END 0 */

/* External variables --------------------------------------------------------*/

/* USER CODE BEGIN EV */

/* USER CODE END EV */

/******************************************************************************/
/*           Cortex Processor Interruption and Exception Handlers          */
/******************************************************************************/

/**
  * @brief This function handles Non maskable interrupt.
  */
void NMI_Handler(void)
{
  /* USER CODE BEGIN NonMaskableInt_IRQn 0 */

  /* USER CODE END NonMaskableInt_IRQn 0 */
  /* USER CODE BEGIN NonMaskableInt_IRQn 1 */
  while (1)
  {
  }
  /* USER CODE END NonMaskableInt_IRQn 1 */
}

/**
  * @brief This function handles Hard fault interrupt.
  */
void HardFault_Handler(void)
{
  /* USER CODE BEGIN HardFault_IRQn 0 */

  /* USER CODE END HardFault_IRQn 0 */
  while (1)
  {
    /* USER CODE BEGIN W1_HardFault_IRQn 0 */

    /* USER CODE END W1_HardFault_IRQn 0 */
  }
}

/**
  * @brief This function handles Memory management fault.
  */
void MemManage_Handler(void)
{
  /* USER CODE BEGIN MemoryManagement_IRQn 0 */

  /* USER CODE END MemoryManagement_IRQn 0 */
  while (1)
  {
    /* USER CODE BEGIN W1_MemoryManagement_IRQn 0 */

    /* USER CODE END W1_MemoryManagement_IRQn 0 */
  }
}

/**
  * @brief This function handles Prefetch fault, memory access fault.
  */
void BusFault_Handler(void)
{
  /* USER CODE BEGIN BusFault_IRQn 0 */

  /* USER CODE END BusFault_IRQn 0 */
  while (1)
  {
    /* USER CODE BEGIN W1_BusFault_IRQn 0 */

    /* USER CODE END W1_BusFault_IRQn 0 */
  }
}

/**
  * @brief This function handles Undefined instruction or illegal state.
  */
void UsageFault_Handler(void)
{
  /* USER CODE BEGIN UsageFault_IRQn 0 */

  /* USER CODE END UsageFault_IRQn 0 */
  while (1)
  {
    /* USER CODE BEGIN W1_UsageFault_IRQn 0 */

    /* USER CODE END W1_UsageFault_IRQn 0 */
  }
}

/**
  * @brief This function handles System service call via SWI instruction.
  */
void SVC_Handler(void)
{
  /* USER CODE BEGIN SVCall_IRQn 0 */

  /* USER CODE END SVCall_IRQn 0 */
  /* USER CODE BEGIN SVCall_IRQn 1 */

  /* USER CODE END SVCall_IRQn 1 */
}

/**
  * @brief This function handles Debug monitor.
  */
void DebugMon_Handler(void)
{
  /* USER CODE BEGIN DebugMonitor_IRQn 0 */

  /* USER CODE END DebugMonitor_IRQn 0 */
  /* USER CODE BEGIN DebugMonitor_IRQn 1 */

  /* USER CODE END DebugMonitor_IRQn 1 */
}

/**
  * @brief This function handles Pendable request for system service.
  */
void PendSV_Handler(void)
{
  /* USER CODE BEGIN PendSV_IRQn 0 */

  /* USER CODE END PendSV_IRQn 0 */
  /* USER CODE BEGIN PendSV_IRQn 1 */

  /* USER CODE END PendSV_IRQn 1 */
}

/**
  * @brief This function handles System tick timer.
  */
void SysTick_Handler(void)
{
  /* USER CODE BEGIN SysTick_IRQn 0 */

  /* USER CODE END SysTick_IRQn 0 */
  HAL_IncTick();
  /* USER CODE BEGIN SysTick_IRQn 1 */

  /* USER CODE END SysTick_IRQn 1 */
}

/******************************************************************************/
/* STM32WLxx Peripheral Interrupt Handlers                                    */
/* Add here the Interrupt Handlers for the used peripherals.                  */
/* For the available peripheral interrupt handler names,                      */
/* please refer to the startup file (startup_stm32wlxx.s).                    */
/******************************************************************************/


/**
  * @brief This function handles USART1 Interrupt.
  */
void USART1_IRQHandler(void)
{
  //This UBX_count will keep track of the position of the UBX message in the UBX message buffer
  static unsigned char UBX_count = 0;

  //This if statement will check if USART1 has received data that is ready to be read and processed.
  if (LL_USART_IsActiveFlag_RXNE_RXFNE(USART1)) {

    UART1_received_data_RX = LL_USART_ReceiveData8(USART1); //This lines reads the received UBX message data from USART1 and stores it in UART1_received_data_RX.
    UART1_received_flag_RX = 1; //This lines sets the received data flag to indicate that data has been received.

    //The below if statement is the start of a new UBX message and the expected first byte should be 0xB5 as this synchronization byte is fixed throughout every UBX message that is received
    if (UBX_count == 0) {
      if (UART1_received_data_RX == 0xb5) {
        M10S_received_buffer_RX[UBX_count] = UART1_received_data_RX; //If the if statement was true, this line stores the received byte in the UBX buffer
        UBX_count++; //Increment the UBX count by one to move forward to the next byte.
      }
    }
    //The below if statement is checking whether the next byte of the UBX message is 0x62 as this is also another synchronization byte that is also fixed throughout every UBX message that is received
    else if (UBX_count == 1) {
      if (UART1_received_data_RX == 0x62) {
        M10S_received_buffer_RX[UBX_count] = UART1_received_data_RX; //If the if statement was true, this line stores the received byte in the UBX buffer
        UBX_count++; //Increment the UBX count by one to move forward to the next byte
      } else //If the second byte is not 0x62, reset the counter to 0
      {
        UBX_count = 0;  // Initialize cnt to 0 if the data is not 0x62
      }
    } else if (UBX_count >= 2 && UBX_count < 35) //If the first two bytes were correct, this else if statement will store bytes from 2 to 34 into the UBX buffer
    {
      M10S_received_buffer_RX[UBX_count] = UART1_received_data_RX;
      UBX_count++; //Increment the count
    } else if (UBX_count == 35) //If its the last byte of the UBX message, we will store the last byte in the UBX buffer
    {
      M10S_received_buffer_RX[UBX_count] = UART1_received_data_RX; //stores the last received byte into the UBX buffer
      UBX_count = 0;  // Reset the count for the next UBX message
      M10S_RX_complete_flag = 1;  // This flag will indicate that a full UBX message reception is complete
    }
  }
}

/**
  * @brief This function handles USART2 Interrupt.
  */
void USART2_IRQHandler(void)
{
  //This if statement checks if USART2 has received data that is ready to be read.
  if (LL_USART_IsActiveFlag_RXNE(USART2)) {
    //This will read the received data from USART2's data register
    //This function read the incoming byte from the data register of USART2 and stores it in UART2_received_data_RX
    UART2_received_data_RX = LL_USART_ReceiveData8(USART2);
    //This will set the received flag to indicate that data has been successfully received.
    //This flag can be used elsewhere in the program to check if new data has arrived
    UART2_received_flag_RX = 1;
    //Below will transmit the received data from USART2 to USART1
    //This line send the data that was just received on USART2 to USART1
    //It effectively forwards the received byte to another serial interface
    LL_USART_TransmitData8(USART1, UART2_received_data_RX);
  }
}

/* USER CODE BEGIN 1 */

/* USER CODE END 1 */
