#include "M10S.h"

M10S_UBX_NAV_POSLLH posllh_structure_variable; // posllh_structure_variable is a structure variable for M10S_UBX_NAV_POSLLH

// These arrays are basically configuration data in order to properly set up the MAX-M10S GNSS module.
// I got these configuration data arrays from the U-Center software, as when using the U-Center software to make these configurations directly,
// the configurations did not save into the MAX-M10S GNSS module. Because of this, it was very inconvenient to always have to go back into U-Center
// and make these changes directly, therefore I have just written up some code that will automatically save the changes into the M10S GNSS without
// the use of U-Center

// For UBX_CFG_PRT, the configuration data in the array is going to set the M10S to output messages in the UBX protocol and also set the USART parameters
const unsigned char UBX_CFG_PRT[] = {
    0xB5, 0x62, 0x06, 0x00, 0x14, 0x00, 0x01, 0x00, 0x00, 0x00,
    0xD0, 0x08, 0x00, 0x00, 0x80, 0x25, 0x00, 0x00, 0x01, 0x00,
    0x01, 0x00, 0x00, 0x00, 0x00, 0x00, 0x9A, 0x79
};

// For UBX_CFG_MSG, the configuration data in the array is going to set the type of message to be output. We set to output POSLLH message to UART1
// of the M10S using the below configuration data.
const unsigned char UBX_CFG_MSG[] = {
    0xB5, 0x62, 0x06, 0x01, 0x08, 0x00, 0x01, 0x02, 0x00, 0x01,
    0x00, 0x00, 0x00, 0x00, 0x13, 0xBE
};

// We change the message output cycle to 5Hz in configuration rate below using the configuration data below. We set the configuration rate to 5Hz
// because this enables the UBX messages to flow relatively fast, as this is indeed needed for real-time tracking for unmanned systems.
const unsigned char UBX_CFG_RATE[] = {
    0xB5, 0x62, 0x06, 0x08, 0x06, 0x00, 0xC8, 0x00, 0x01, 0x00,
    0x01, 0x00, 0xDE, 0x6A
};

// The below configuration data in the array is used to save all configurations that we have made above.
const unsigned char UBX_CFG_CFG[] = {
    0xB5, 0x62, 0x06, 0x09, 0x0D, 0x00, 0x00, 0x00, 0x00, 0x00,
    0xFF, 0xFF, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x17, 0x31,
    0xBF
};

// In the function directly below, we are essentially transmitting these arrays to USART1
// The function uses a loop to send each byte of the data array
// The function will wait until the USART transmit data register is empty before sending the next byte
void M10S_TransmitData(unsigned char* UBX_data, unsigned char UBX_message_length)
{
    int i = 0; // This line will initialize a counter variable 'i' to 0. This variable will be used to iterate through the UBX data array.

    // The if statement will begin operation once the UBX_message_length is greater than 0
    if (UBX_message_length > 0)
    {
        // A do-while loop is placed here to transmit each byte of the UBX data array over USART1
        do
        {
            // This line below will wait for the USART1 transmit data register to be empty.
            // The function LL_USART_IsActiveFlag_TXE returns true if the transmit data register is empty, indicating that it is ready to transmit the next byte
            // The while loop will keep checking the condition until the register is empty
            while (!LL_USART_IsActiveFlag_TXE(USART1));

            // This line directly below will transmit the current byte of UBX data
            // The function LL_USART_TransmitData8 takes two arguments: the USART instance (USART1) and the data byte to be transmitted (*(UBX_data + i)).
            LL_USART_TransmitData8(USART1, *(UBX_data + i));

            i++; // Incrementation

        } while (i < UBX_message_length); // The loop will continue as long as i is less than UBX_message_length
    }
}

// Since we are working with USART1, we need to initialize USART1. We initialize USART1 by copying and pasting the code defined in MX_USART1_Init(void) in main.c.
// This will basically initialize USART1 with specific settings such as 9600 baud rate, 8 data bits, 1 stop bit, no parity
// Enables USART1 interrupts
void M10S_USART1_Initialization(void)
{
    LL_USART_InitTypeDef USART_InitStruct = {0};
    LL_GPIO_InitTypeDef GPIO_InitStruct = {0};

    /* Peripheral clock enable */
    LL_APB2_GRP1_EnableClock(LL_APB2_GRP1_PERIPH_USART1);
    LL_AHB2_GRP1_EnableClock(LL_AHB2_GRP1_PERIPH_GPIOB);

    /**USART1 GPIO Configuration
    PB7   ------> USART1_RX
    PB6   ------> USART1_TX
    */
    GPIO_InitStruct.Pin = LL_GPIO_PIN_7 | LL_GPIO_PIN_6;
    GPIO_InitStruct.Mode = LL_GPIO_MODE_ALTERNATE;
    GPIO_InitStruct.Speed = LL_GPIO_SPEED_FREQ_LOW;
    GPIO_InitStruct.OutputType = LL_GPIO_OUTPUT_PUSHPULL;
    GPIO_InitStruct.Pull = LL_GPIO_PULL_NO;
    GPIO_InitStruct.Alternate = LL_GPIO_AF_7;
    LL_GPIO_Init(GPIOB, &GPIO_InitStruct);

    /* USART1 interrupt Init */
    NVIC_SetPriority(USART1_IRQn, NVIC_EncodePriority(NVIC_GetPriorityGrouping(), 0, 0));
    NVIC_EnableIRQ(USART1_IRQn);

    USART_InitStruct.BaudRate = 9600;
    USART_InitStruct.DataWidth = LL_USART_DATAWIDTH_8B;
    USART_InitStruct.StopBits = LL_USART_STOPBITS_1;
    USART_InitStruct.Parity = LL_USART_PARITY_NONE;
    USART_InitStruct.TransferDirection = LL_USART_DIRECTION_TX_RX;
    USART_InitStruct.HardwareFlowControl = LL_USART_HWCONTROL_NONE;
    USART_InitStruct.OverSampling = LL_USART_OVERSAMPLING_16;
    LL_USART_Init(USART1, &USART_InitStruct);
    LL_USART_ConfigAsyncMode(USART1);
    LL_USART_Enable(USART1);
}

// If M10S_Initialization is called once in the main function, it initializes and transmits all M10S configuration data sets.
// This function is designed to initialize the USART1 peripheral and configures the MAX-M10S GNSS module by sending the configuration arrays to the GNSS module via UART1.
void M10S_Initialization(void)
{
    M10S_USART1_Initialization(); // Call M10S_USART1_Initialization() inside of M10S_Initialization

    M10S_TransmitData(&UBX_CFG_PRT[0], sizeof(UBX_CFG_PRT)); // This line sends the UBX_CFG_PRT configuration array to the MAX-M10S module via USART1. &UBX_CFG_PRT[0] provides an address of the data in the array. sizeof(UBX_CFG_PRT) provides the total size of the data that needs to be transmitted.
    HAL_Delay(100); // Wait for 100 milliseconds to allow the GNSS module to process the command
    M10S_TransmitData(&UBX_CFG_MSG[0], sizeof(UBX_CFG_MSG)); // This line sends the UBX_CFG_MSG configuration array to the MAX-M10S module via USART1. &UBX_CFG_MSG[0] provides an address of the data in the array sizeof(UBX_CFG_MSG) provides the total size of the data that needs to be transmitted.
    HAL_Delay(100); // Wait for 100 milliseconds to allow the GNSS module to process the command
    M10S_TransmitData(&UBX_CFG_RATE[0], sizeof(UBX_CFG_RATE)); // This line sends the UBX_CFG_RATE configuration array to the MAX-M10S module via USART1. &UBX_CFG_RATE[0] provides an address of the data in the array. sizeof(UBX_CFG_RATE) provides the total size of the data that needs to be transmitted.
    HAL_Delay(100); // Wait for 100 milliseconds to allow the GNSS module to process the command
    M10S_TransmitData(&UBX_CFG_CFG[0], sizeof(UBX_CFG_CFG)); // This line sends the UBX_CFG_CFG configuration array to the MAX-M10S module via USART1. &UBX_CFG_CFG[0] provides an address of the data in the array. sizeof(UBX_CFG_CFG) provides the total size of the data that needs to be transmitted.
}

// This checksum algorithm is a method of detecting errors such as missing data in data communication. This ensures the data is reliable.
// The checksum function iterates through the data bytes from the pointer "UBX_data", which was able to extract the UBX message from the "&" pass by reference operator.
// The calculation for checksum excludes the SYNC bytes and the final checksum bytes themselves, to compute the checksum values CK_A and CK_B. By continuously adding each byte value to CK_A and CK_B
unsigned char M10S_UBX_CHKSUM_Check(unsigned char* UBX_data, unsigned char UBX_message_length) // unsigned char UBX_message_len is the length, the length should be 36 bytes
{
    unsigned char CK_A = 0, CK_B = 0; // CK_A and CK_B will have 1 byte each.

    // We set the index i to 2 in order to start iterating through the UBX-NAV POSLLH message, excluding the first two bytes SYNC 1 and SYNC 2 because they are fixed bytes.
    // We iterate until UBX_message_len-2 because the last two bytes of the UBX-NAV POSLLH message are checksum bytes. They are not in the range of checksum calculation.
    for (int i = 2; i < UBX_message_length - 2; i++)
    {
        CK_A = CK_A + UBX_data[i];
        CK_B = CK_B + CK_A;
    }

    // This line checks if the calculated checksum values (CK_A and CK_B) match the checksum bytes in the received UBX-NAV POSLLH message.
    // UBX_data[UBX_message_len - 2] contains the checksum byte CK_A, which is the second-to-last byte in the UBX_data array.
    // UBX_data[UBX_message_len - 1] contains the checksum byte CK_B, which is the last byte in the UBX_data array.
    // The function returns true (1) if both checksums match, indicating valid data. Otherwise, it returns false (0).
    return ((CK_A == UBX_data[UBX_message_length - 2]) && (CK_B == UBX_data[UBX_message_length - 1]));
}

// This Parsing function is used to extract and store information from a UBX NAV-POSLLH message into a M10S_UBX_NAV_POSLLH structure.
// unsigned char* UBX_data is used to represent raw binary data from the UBX NAV-POSLLH message. We used unsigned char due to its 8-bit data type size.
// A pointer to an array (UBX_data) of unsigned char which holds the raw binary data from the UBX NAV-POSLLH message.
// A pointer to M10_UBX_NAV_POSLLH structure where the parsed information will be stored.
void M10S_UBX_NAV_POSLLH_Parsing(unsigned char* UBX_data, M10S_UBX_NAV_POSLLH* posllh_structure_variable) // posllh is a pointer to structure type M10S_UBX_NAV_POSLLH where the parsed information from data will be stored.
{
    // The values in the array for data represent the location of a UBX message field. It is important to note that each location is indeed a byte.
    posllh_structure_variable->CLASS = UBX_data[2]; // Class is 0x01 by default as represented by the integration manual 112-113
    posllh_structure_variable->ID = UBX_data[3]; // ID is 0x02 by default as represented by the integration manual 112-113

    // The length of the UBX NAV-POSLLH will be a combination of two bytes.
    // These two bytes should represent the value of 28 in hex, this can be seen in the integration manual on page 113.
    // We use bitwise OR ( | ) throughout this parsing function in order to combine the bytes together. The length of the payload is 28 bytes according to how the UBX message is structured.
    posllh_structure_variable->length = UBX_data[4] | UBX_data[5] << 8;

    // We bitwise shift (<<8, <<16, <<24) in order to align each byte from the data array data[6]-data[9] and so on and so forth for the following examples.
    // Each of the following parameter fields below will have 4 bytes. Therefore each parameter field will be a combination of 32 bits using bitwise OR ( | ).
    // Each of the following parameter fields will have 4 bytes due to the structure of the UBX NAV-POSLLH message.
    posllh_structure_variable->iTOW = UBX_data[6] | UBX_data[7] << 8 | UBX_data[8] << 16 | UBX_data[9] << 24;
    posllh_structure_variable->longitude = UBX_data[10] | UBX_data[11] << 8 | UBX_data[12] << 16 | UBX_data[13] << 24;
    posllh_structure_variable->latitude = UBX_data[14] | UBX_data[15] << 8 | UBX_data[16] << 16 | UBX_data[17] << 24;
    posllh_structure_variable->altitude = UBX_data[18] | UBX_data[19] << 8 | UBX_data[20] << 16 | UBX_data[21] << 24;
    posllh_structure_variable->hMSL = UBX_data[22] | UBX_data[23] << 8 | UBX_data[24] << 16 | UBX_data[25] << 24;
    posllh_structure_variable->hAcc = UBX_data[26] | UBX_data[27] << 8 | UBX_data[28] << 16 | UBX_data[29] << 24;
    posllh_structure_variable->vAcc = UBX_data[30] | UBX_data[31] << 8 | UBX_data[32] << 16 | UBX_data[33] << 24;
}
