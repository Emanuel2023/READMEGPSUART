#ifndef M10S_UBX_NAV_POSLLH_H
#define M10S_UBX_NAV_POSLLH_H

#include <stdint.h> // For standard integer types
#include "main.h" // Include the main header file

// Define the structure for UBX NAV-POSLLH message
typedef struct _M10S_UBX_NAV_POSLLH
{
    uint8_t CLASS;    // Identification field of the UBX message.
    uint8_t ID;       // Identification field of the UBX message.
    uint16_t length;  // Length of the UBX message in bytes

    uint32_t iTOW;    // Data field extracted from the UBX message.
    int32_t longitude; // Longitude extracted from the UBX message.
    int32_t latitude;  // Latitude extracted from the UBX message.
    int32_t altitude;  // Altitude in ellipsoid.
    int32_t hMSL;      // Height above ellipsoid
    uint32_t hAcc;     // Horizontal accuracy estimate
    uint32_t vAcc;     // Vertical accuracy estimate

    double longitude_f64; // Used for proper longitude precision
    double latitude_f64;  // Used for proper latitude precision
} M10S_UBX_NAV_POSLLH;

// Declare an external variable for the UBX NAV-POSLLH structure
extern M10S_UBX_NAV_POSLLH posllh_structure_variable; // 'extern' allows this variable to be accessed in other files

// Function declarations for operations on UBX NAV-POSLLH
uint8_t M10S_UBX_CHKSUM_Check(uint8_t* UBX_data, uint8_t UBX_message_length); // Function to check the checksum of UBX data
void M10S_UBX_NAV_POSLLH_Parsing(uint8_t* UBX_data, M10S_UBX_NAV_POSLLH* posllh_structure_variable); // Function to parse UBX NAV-POSLLH data
void M10S_TransmitData(unsigned char* UBX_data, unsigned char UBX_message_length); // Function to transmit UBX data
void M10S_USART_Initialization(void); // Function to initialize USART
void M10S_Initialization(void); // Function to initialize M10S module

#endif
